document.addEventListener('DOMContentLoaded', () => {
    console.log('Portfolio của Nguyễn Văn A đã load xong!');

    // Chỉ hiện lời chào một lần mỗi phiên, tránh phiền khi chuyển trang
    if (!sessionStorage.getItem('welcomed')) {
        alert('Chào mừng bạn đến với portfolio thật trên Internet của mình!');
        sessionStorage.setItem('welcomed', '1');
    }

    const form = document.getElementById('contact-form');
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('Cảm ơn bạn đã gửi lời nhắn!');
            form.reset();
        });
    }
});
